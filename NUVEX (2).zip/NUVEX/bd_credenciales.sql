CREATE DATABASE IF NOT EXISTS credenciales_cfe
  CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci;
USE credenciales_cfe;

-- ================= ADMINISTRADOR =================
CREATE TABLE administrador (
    id_admin       INT AUTO_INCREMENT PRIMARY KEY,
    usuario        VARCHAR(50)  NOT NULL UNIQUE,
    password_hash  VARCHAR(255) NOT NULL,
    creado_en      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ================= ÁREA =================
CREATE TABLE area (
    id_area  INT AUTO_INCREMENT PRIMARY KEY,
    nombre   VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- ================= TRABAJADOR =================
CREATE TABLE trabajador (
    id_trabajador   INT AUTO_INCREMENT PRIMARY KEY,
    num_trabajador  VARCHAR(30)  NOT NULL UNIQUE,
    nombre          VARCHAR(150) NOT NULL,
    curp            CHAR(18)     NOT NULL UNIQUE,
    edad            TINYINT UNSIGNED NOT NULL,
    sexo            VARCHAR(20)  NOT NULL,
    telefono        VARCHAR(20),
    correo          VARCHAR(120),
    cargo           VARCHAR(100) NOT NULL,
    foto            MEDIUMTEXT,
    id_area         INT NOT NULL,
    CONSTRAINT fk_trabajador_area
        FOREIGN KEY (id_area) REFERENCES area(id_area)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ================= CREDENCIAL =================
CREATE TABLE credencial (
    id_credencial  INT AUTO_INCREMENT PRIMARY KEY,
    num_tarjeta    VARCHAR(30) NOT NULL UNIQUE,
    fecha_inicio   DATE,
    fecha_vigencia DATE NOT NULL,
    estado         ENUM('Vigente','Inactiva','Vencida') NOT NULL DEFAULT 'Vigente',
    id_trabajador  INT NOT NULL,
    creado_en      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_credencial_trabajador
        FOREIGN KEY (id_trabajador) REFERENCES trabajador(id_trabajador)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- ================= NOTIFICACIÓN =================
CREATE TABLE notificacion (
    id_notificacion INT AUTO_INCREMENT PRIMARY KEY,
    id_trabajador   INT NOT NULL,
    tipo            VARCHAR(120) NOT NULL,
    vigencia        DATE,
    estado          VARCHAR(20),
    correo_destino  VARCHAR(120),
    fecha_envio     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notificacion_trabajador
        FOREIGN KEY (id_trabajador) REFERENCES trabajador(id_trabajador)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- ================= VISTA: estado calculado (como getComputedStatus) =================
CREATE VIEW v_credenciales AS
SELECT t.id_trabajador, t.nombre, t.num_trabajador, a.nombre AS area, t.cargo,
       c.num_tarjeta, c.fecha_inicio, c.fecha_vigencia,
       CASE
         WHEN c.estado = 'Inactiva'        THEN 'Inactiva'
         WHEN c.fecha_vigencia < CURDATE() THEN 'Vencida'
         ELSE 'Vigente'
       END AS estado_calculado
FROM credencial c
JOIN trabajador t ON t.id_trabajador = c.id_trabajador
JOIN area a       ON a.id_area = t.id_area;

-- ================= DATO INICIAL: administrador =================
-- Solo de prueba. En producción genera el hash con bcrypt desde el servidor.
INSERT INTO administrador (usuario, password_hash)
VALUES ('admin', SHA2('CFE2025', 256));