// ================= NOTIFICACIONES =================
function triggerNotification(worker, tipoNotif) {
    const payload = {
        trabajador: worker.nombre,
        correo_destino: worker.correo,
        num_trabajador: worker.numTrabajador,
        num_tarjeta: worker.numTarjeta,
        tipo_notificacion: tipoNotif,
        vigencia: worker.vigencia,
        estado_actualizado: getComputedStatus(worker),
        mensaje: `Se ha procesado un evento de credencialización CFE: ${tipoNotif}. Estado: ${getComputedStatus(worker)}.`
    };

    fetch(FORMSPREE_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify(payload)
    })
    .then(response => {
        if (response.ok) {
            console.log("Notificación enviada con éxito vía Formspree");
            showToast(`Notificación enviada a ${worker.correo}`);
        } else {
            console.error("Error al enviar con Formspree");
        }
    })
    .catch(error => console.error("Error de red Formspree:", error));

    notificationsLog.unshift({
        nombre: worker.nombre,
        numTrabajador: worker.numTrabajador,
        numTarjeta: worker.numTarjeta,
        tipo: tipoNotif,
        vigencia: worker.vigencia,
        estado: getComputedStatus(worker),
        correo: worker.correo || "admin@cfe.gob.mx"
    });
    saveData();
}

function renderNotificationsTable() {
    const tbody = document.getElementById('notifications-tbody');
    tbody.innerHTML = '';

    if (notificationsLog.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="p-6 text-center text-slate-400">No hay notificaciones registradas.</td></tr>`;
        return;
    }

    notificationsLog.forEach(n => {
        tbody.innerHTML += `
            <tr class="hover:bg-emerald-50/50 border-b border-emerald-50 text-xs">
                <td class="p-3 font-bold text-emerald-950">${n.nombre}</td>
                <td class="p-3 font-mono text-slate-600">#${n.numTrabajador} / <span class="text-emerald-700">${n.numTarjeta}</span></td>
                <td class="p-3"><span class="bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded border border-emerald-200">${n.tipo}</span></td>
                <td class="p-3 text-slate-600">${n.vigencia}</td>
                <td class="p-3 font-bold text-slate-700">${n.estado}</td>
                <td class="p-3 text-slate-500 italic">${n.correo}</td>
            </tr>
        `;
    });
}
