// ================= VISTA PÚBLICA Y SIMULADOR DE ESCÁNER =================
async function showPublicView(p) {
    document.getElementById('admin-app').classList.add('hidden');
    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('toast-container').classList.add('hidden');
    document.getElementById('public-view').classList.remove('hidden');

    const status = getStatusFromPayload(p);
    const badge = {
        Vigente: 'bg-emerald-100 text-emerald-800',
        Inactiva: 'bg-amber-100 text-amber-800',
        Vencida: 'bg-rose-100 text-rose-800'
    }[status];
    const photo = payloadPhotoSrc(p);

    document.getElementById('public-body').innerHTML = `
        <div class="flex items-center space-x-4">
            ${photo ? `<img src="${photo}" class="w-24 h-32 object-cover rounded-xl border-2 border-emerald-600 shadow">` : ''}
            <div class="space-y-1">
                <h2 class="text-lg font-extrabold text-emerald-950 leading-tight">${p.n}</h2>
                <span class="inline-block px-3 py-1 rounded-full text-xs font-bold ${badge}">${status.toUpperCase()}</span>
            </div>
        </div>
        <div class="text-sm space-y-2">
            <div class="flex justify-between border-b border-emerald-50 py-1"><span class="text-slate-500">No. Trabajador</span><strong>${p.t}</strong></div>
            <div class="flex justify-between border-b border-emerald-50 py-1"><span class="text-slate-500">Área de adscripción</span><strong class="text-right">${p.a}</strong></div>
            <div class="flex justify-between border-b border-emerald-50 py-1"><span class="text-slate-500">Cargo</span><strong class="text-right">${p.c}</strong></div>
            <div class="flex justify-between border-b border-emerald-50 py-1"><span class="text-slate-500">No. Tarjeta</span><strong class="font-mono">${p.k}</strong></div>
            <div class="flex justify-between border-b border-emerald-50 py-1"><span class="text-slate-500">Vigencia</span><strong>${p.i || 'N/A'} al ${p.v}</strong></div>
        </div>`;

    const doc = await buildCredentialPDF(p);
    document.getElementById('btn-public-pdf').onclick = () => doc.save(safeFileName(p));
    setTimeout(() => { try { doc.save(safeFileName(p)); } catch (e) {} }, 600);
}

function checkPublicHash() {
    if (!location.hash.startsWith('#c=')) return false;
    try {
        showPublicView(decodePayload(location.hash.slice(3)));
    } catch (e) {
        document.body.innerHTML = '<div class="p-10 text-center text-rose-700 font-bold">Código QR inválido o dañado.</div>';
    }
    return true;
}

function populateQRSelect() {
    const select = document.getElementById('select-qr-sim');
    const q = document.getElementById('search-qr-sim').value;
    const prev = select.value;
    const list = filterWorkersByQuery(q);
    const result = document.getElementById('qr-result-card');
    select.innerHTML = '';

    if (workers.length === 0) {
        select.innerHTML = `<option value="">No hay trabajadores registrados</option>`;
        result.innerHTML = `<div class="p-8 text-center text-slate-400 font-bold">Sin registros para escanear.</div>`;
        return;
    }
    if (list.length === 0) {
        select.innerHTML = `<option value="">Sin coincidencias</option>`;
        result.innerHTML = `<div class="p-8 text-center text-slate-400 font-bold">Ningún trabajador coincide con la búsqueda.</div>`;
        return;
    }

    list.forEach(w => {
        select.innerHTML += `<option value="${w.id}">${w.nombre} · No. ${w.numTrabajador} [QR Token: ${w.numTarjeta}]</option>`;
    });
    if (list.some(w => String(w.id) === prev)) select.value = prev;
    simulateQRScan();
}

function simulateQRScan() {
    const id = document.getElementById('select-qr-sim').value;
    const w = workers.find(x => x.id == id);
    const container = document.getElementById('qr-result-card');

    if (!w) {
        container.innerHTML = `<div class="p-8 text-center text-rose-600 font-bold">Credencial no encontrada en el sistema CFE.</div>`;
        return;
    }

    const status = getComputedStatus(w);
    let statusBadge = `<span class="bg-emerald-100 text-emerald-800 font-bold px-3 py-1 rounded-full text-xs">VIGENTE / AUTÉNTICA</span>`;
    if (status === 'Inactiva') statusBadge = `<span class="bg-amber-100 text-amber-800 font-bold px-3 py-1 rounded-full text-xs">INACTIVA</span>`;
    if (status === 'Vencida') statusBadge = `<span class="bg-rose-100 text-rose-800 font-bold px-3 py-1 rounded-full text-xs">EXPIRED / VENCIDA</span>`;

    container.innerHTML = `
        <div class="bg-emerald-950 text-white p-6 text-center border-b border-emerald-900">
            <span class="text-[10px] uppercase font-bold tracking-widest text-emerald-300 block mb-1">Verificación Oficial de Credencial CFE</span>
            <h4 class="text-lg font-extrabold">${w.nombre}</h4>
            <div class="mt-2">${statusBadge}</div>
        </div>
        <div class="p-6 space-y-4">
            <div class="flex items-center space-x-4 border-b border-emerald-100 pb-4">
                <img src="${w.foto}" class="w-20 h-24 object-cover rounded-xl border-2 border-emerald-600 shadow-md">
                <div class="space-y-1 text-sm">
                    <p><span class="text-slate-400 text-xs block">Número de Trabajador</span> <strong class="text-emerald-950">${w.numTrabajador}</strong></p>
                    <p><span class="text-slate-400 text-xs block">Área & Cargo</span> <strong class="text-emerald-950">${w.area} - ${w.cargo}</strong></p>
                    <p><span class="text-slate-400 text-xs block">No. Tarjeta Único</span> <strong class="text-emerald-700 font-mono">${w.numTarjeta}</strong></p>
                </div>
            </div>
            <div class="space-y-2 text-xs text-slate-600">
                <div class="flex justify-between py-1 border-b border-emerald-50">
                    <span>Vigencia Autorizada:</span>
                    <span class="font-bold text-emerald-950">Del ${w.inicio || 'N/A'} al ${w.vigencia}</span>
                </div>
                <div class="flex justify-between py-1 border-b border-emerald-50">
                    <span>Estado de Validez:</span>
                    <span class="font-bold text-emerald-950">${status}</span>
                </div>
            </div>
            <div class="bg-emerald-50 border border-emerald-200 p-3 rounded-xl text-[11px] text-emerald-900 leading-relaxed flex items-start space-x-2">
                <i class="fa-solid fa-user-shield text-emerald-700 mt-0.5"></i>
                <span><strong>Nota de Privacidad CFE:</strong> Por seguridad y normativa del sistema, <u>la CURP completa y los datos de contacto de emergencia están ocultos</u> en esta consulta pública QR.</span>
            </div>
        </div>
    `;
}
