// ================= AUTENTICACIÓN Y NUBE =================
function isLoggedIn() {
    return !!(firebaseReady && firebase.auth().currentUser);
}

function showLogin() {
    document.getElementById('admin-app').classList.add('hidden');
    document.getElementById('login-screen').classList.remove('hidden');
    document.getElementById('login-user').focus();
}

function showApp() {
    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('admin-app').classList.remove('hidden');
    renderTable();
}

async function doLogin(e) {
    e.preventDefault();
    const u = document.getElementById('login-user').value.trim();
    const pw = document.getElementById('login-pass').value;
    const err = document.getElementById('login-error');

    if (!firebaseReady) {
        err.innerText = 'Falta configurar Firebase. Abre el archivo y completa firebaseConfig con los datos de tu proyecto.';
        err.classList.remove('hidden');
        return;
    }
    if (u.toLowerCase() !== ADMIN_USER) {
        err.innerText = 'Usuario o contraseña incorrectos.';
        err.classList.remove('hidden');
        return;
    }

    try {
        await firebase.auth().signInWithEmailAndPassword(ADMIN_FIREBASE_EMAIL, pw);
        err.classList.add('hidden');
        document.getElementById('login-pass').value = '';
        showToast('Acceso autorizado. Sincronizando información...');
    } catch (error) {
        console.error('Error de inicio de sesión:', error);
        err.innerText = error.code === 'auth/network-request-failed'
            ? 'No hay conexión. Revisa tu Internet e inténtalo de nuevo.'
            : 'Usuario o contraseña incorrectos.';
        err.classList.remove('hidden');
    }
}

async function logout() {
    try {
        if (cloudUnsubscribe) cloudUnsubscribe();
        cloudUnsubscribe = null;
        cloudReady = false;
        cloudUser = null;
        await firebase.auth().signOut();
    } catch (error) {
        console.error('Error al cerrar sesión:', error);
        showToast('No se pudo cerrar la sesión. Inténtalo de nuevo.', 'error');
    }
    showLogin();
}

function startCloudSync(user) {
    if (!firebaseReady || !user) return;
    if (cloudUnsubscribe) cloudUnsubscribe();
    cloudUser = user;
    cloudReady = false;
    firstCloudSnapshot = true;

    cloudUnsubscribe = cloudDocument.onSnapshot(async (snapshot) => {
        if (!snapshot.exists) {
            const initialData = {
                workers: workers,
                notificationsLog: notificationsLog,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            };
            try {
                await cloudDocument.set(initialData);
            } catch (error) {
                console.error('No se pudieron migrar los datos iniciales:', error);
                showToast('No se pudieron cargar los datos de la nube. Revisa la configuración.', 'error');
            }
        } else {
            const data = snapshot.data() || {};
            workers = Array.isArray(data.workers) ? data.workers : [];
            notificationsLog = Array.isArray(data.notificationsLog) ? data.notificationsLog : [];
            localStorage.setItem('credencial_workers', JSON.stringify(workers));
            localStorage.setItem('credencial_notifications', JSON.stringify(notificationsLog));
        }

        cloudReady = true;
        if (firstCloudSnapshot) {
            firstCloudSnapshot = false;
            showApp();
            showToast('Información sincronizada correctamente.');
        } else if (!document.getElementById('admin-app').classList.contains('hidden')) {
            renderTable();
            updateMetrics();
        }
    }, (error) => {
        console.error('Error de sincronización Firebase:', error);
        showToast('Error al sincronizar con la nube. Revisa tu conexión y las reglas de Firestore.', 'error');
    });
}
