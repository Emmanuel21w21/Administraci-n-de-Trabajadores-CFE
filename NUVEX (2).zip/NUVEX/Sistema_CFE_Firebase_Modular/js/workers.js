// ================= GESTIÓN DE TRABAJADORES =================
function renderTable() {
    const tbody = document.getElementById('workers-tbody');
    const search = document.getElementById('search-input').value.toLowerCase();
    const filterStatus = document.getElementById('filter-status').value;

    tbody.innerHTML = '';

    const filtered = workers.filter(w => {
        const status = getComputedStatus(w);
        const matchesSearch = w.nombre.toLowerCase().includes(search) ||
                              w.curp.toLowerCase().includes(search) ||
                              (w.telefono && w.telefono.includes(search)) ||
                              w.numTarjeta.toLowerCase().includes(search) ||
                              w.area.toLowerCase().includes(search);
        const matchesStatus = filterStatus === 'todos' || status === filterStatus;
        return matchesSearch && matchesStatus;
    });

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" class="py-8 text-center text-slate-400 font-medium">No hay trabajadores registrados. Haz clic en "Nuevo Trabajador" para comenzar.</td></tr>`;
        updateMetrics();
        return;
    }

    filtered.forEach(w => {
        const status = getComputedStatus(w);
        let badgeClass = 'bg-emerald-100 text-emerald-800 border-emerald-300';
        if (status === 'Inactiva') badgeClass = 'bg-amber-100 text-amber-800 border-amber-200';
        if (status === 'Vencida') badgeClass = 'bg-rose-100 text-rose-800 border-rose-200';

        tbody.innerHTML += `
            <tr class="hover:bg-emerald-50/50 transition-all border-b border-emerald-50">
                <td class="py-3.5 px-4 flex items-center space-x-3">
                    <img src="${w.foto || 'https://via.placeholder.com/150'}" onerror="this.src='https://via.placeholder.com/150'" class="w-10 h-10 rounded-xl object-cover border border-emerald-200 shadow-sm">
                    <div>
                        <p class="font-bold text-emerald-950">${w.nombre}</p>
                        <p class="text-xs text-slate-400">ID System: #${w.id}</p>
                    </div>
                </td>
                <td class="py-3.5 px-4">
                    <span class="font-mono text-xs font-semibold text-emerald-900 block">${w.curp}</span>
                    <span class="text-xs text-slate-500 font-medium"><i class="fa-solid fa-phone text-[10px] mr-1 text-emerald-600"></i>${w.telefono || 'Sin registro'}</span>
                </td>
                <td class="py-3.5 px-4">
                    <span class="text-xs font-semibold text-slate-700 block">No. ${w.numTrabajador}</span>
                    <span class="font-mono text-xs text-emerald-700 font-bold">${w.numTarjeta}</span>
                </td>
                <td class="py-3.5 px-4">
                    <span class="font-semibold text-emerald-950 text-xs block">${w.area}</span>
                    <span class="text-xs text-slate-500">${w.cargo}</span>
                </td>
                <td class="py-3.5 px-4 text-xs font-medium text-slate-600">
                    Del ${w.inicio || 'N/A'} <br>Al ${w.vigencia}
                </td>
                <td class="py-3.5 px-4">
                    <span class="px-2.5 py-1 rounded-full text-[11px] font-bold border ${badgeClass}">${status}</span>
                </td>
                <td class="py-3.5 px-4 text-center space-x-2">
                    <button onclick="openModal(${w.id})" title="Editar datos" class="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition inline-flex items-center justify-center">
                        <i class="fa-solid fa-pen"></i>
                    </button>
                    <button onclick="toggleWorkerStatus(${w.id})" title="Activar/Desactivar" class="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 hover:bg-amber-100 transition inline-flex items-center justify-center">
                        <i class="fa-solid fa-power-off"></i>
                    </button>
                    <button onclick="deleteWorker(${w.id})" title="Eliminar" class="w-8 h-8 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 transition inline-flex items-center justify-center">
                        <i class="fa-solid fa-trash-can"></i>
                    </button>
                </td>
            </tr>
        `;
    });

    updateMetrics();
}

function toggleWorkerStatus(id) {
    const worker = workers.find(w => w.id === id);
    if (worker) {
        worker.estado = (worker.estado === 'Vigente' || worker.estado === 'Vencida') ? 'Inactiva' : 'Vigente';
        if (worker.estado === 'Inactiva') {
            triggerNotification(worker, "El administrador desactivó la credencial CFE");
        }
        saveData();
        renderTable();
        showToast(`Estado de ${worker.nombre} cambiado a ${worker.estado}.`);
    }
}

function openModal(id = null) {
    const modal = document.getElementById('worker-modal');
    const form = document.getElementById('worker-form');
    form.reset();

    if (id) {
        document.getElementById('modal-title').innerText = "Modificar Datos del Trabajador CFE";
        const w = workers.find(x => x.id === id);
        document.getElementById('field-id').value = w.id;
        document.getElementById('field-nombre').value = w.nombre;
        document.getElementById('field-curp').value = w.curp;
        document.getElementById('field-edad').value = w.edad;
        document.getElementById('field-sexo').value = w.sexo;
        document.getElementById('field-telefono').value = w.telefono || "";
        document.getElementById('field-numtrabajador').value = w.numTrabajador;
        document.getElementById('field-numtarjeta').value = w.numTarjeta;
        document.getElementById('field-correo').value = w.correo || "";
        document.getElementById('field-area').value = w.area;
        document.getElementById('field-cargo').value = w.cargo;
        document.getElementById('field-inicio').value = w.inicio || "";
        document.getElementById('field-vigencia').value = w.vigencia;
        document.getElementById('field-estado').value = w.estado;
        document.getElementById('field-foto-url').value = w.foto;
    } else {
        document.getElementById('modal-title').innerText = "Registrar Nuevo Trabajador CFE";
        document.getElementById('field-id').value = '';
        document.getElementById('field-inicio').value = new Date().toISOString().split('T')[0];
    }

    modal.classList.remove('hidden');
}

function closeModal() {
    document.getElementById('worker-modal').classList.add('hidden');
}

function handleFileUpload(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('field-foto-url').value = e.target.result;
        };
        reader.readAsDataURL(file);
    }
}

function saveWorker(e) {
    e.preventDefault();
    const id = document.getElementById('field-id').value;
    const numTarjeta = document.getElementById('field-numtarjeta').value.trim();

    const isDuplicate = workers.some(w => w.numTarjeta.toLowerCase() === numTarjeta.toLowerCase() && w.id != id);
    if (isDuplicate) {
        showToast(`Error: El número de tarjeta "${numTarjeta}" ya existe en el sistema CFE.`, 'error');
        return;
    }

    const workerData = {
        id: id ? parseInt(id) : Date.now(),
        nombre: document.getElementById('field-nombre').value.trim(),
        curp: document.getElementById('field-curp').value.trim().toUpperCase(),
        edad: parseInt(document.getElementById('field-edad').value),
        sexo: document.getElementById('field-sexo').value,
        telefono: document.getElementById('field-telefono').value.trim(),
        numTrabajador: document.getElementById('field-numtrabajador').value.trim(),
        numTarjeta: numTarjeta,
        correo: document.getElementById('field-correo').value.trim(),
        area: document.getElementById('field-area').value.trim(),
        cargo: document.getElementById('field-cargo').value.trim(),
        inicio: document.getElementById('field-inicio').value,
        vigencia: document.getElementById('field-vigencia').value,
        estado: document.getElementById('field-estado').value,
        foto: document.getElementById('field-foto-url').value.trim() || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'
    };

    if (id) {
        const index = workers.findIndex(w => w.id == id);
        const oldVigencia = workers[index].vigencia;
        workers[index] = workerData;
        if (oldVigencia !== workerData.vigencia) {
            triggerNotification(workerData, "Modificación de fecha de vencimiento CFE");
        } else {
            triggerNotification(workerData, "Actualización de información administrativa CFE");
        }
        showToast("Datos actualizados correctamente.");
    } else {
        workers.push(workerData);
        triggerNotification(workerData, "Generación de nueva credencial CFE");
        showToast("Nuevo trabajador registrado exitosamente y notificación enviada.");
    }

    saveData();
    renderTable();
    closeModal();
}

function deleteWorker(id) {
    if (confirm("¿Estás seguro de eliminar este registro permanentemente del sistema CFE?")) {
        workers = workers.filter(w => w.id !== id);
        saveData();
        renderTable();
        showToast("Registro eliminado.");
    }
}
