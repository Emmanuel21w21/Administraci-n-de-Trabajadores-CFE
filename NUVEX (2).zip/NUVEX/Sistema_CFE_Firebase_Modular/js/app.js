// ================= INICIALIZACIÓN DE LA APLICACIÓN =================
window.onload = function() {
    if (checkPublicHash()) return;
    showLogin();

    if (!firebaseReady) {
        const err = document.getElementById('login-error');
        err.innerText = 'Este archivo necesita la configuración de Firebase para iniciar sesión y sincronizar los datos.';
        err.classList.remove('hidden');
        return;
    }

    firebase.auth().onAuthStateChanged((user) => {
        if (user) {
            startCloudSync(user);
        } else {
            if (cloudUnsubscribe) cloudUnsubscribe();
            cloudUnsubscribe = null;
            cloudReady = false;
            cloudUser = null;
            showLogin();
        }
    });
};

window.addEventListener('hashchange', () => {
    if (location.hash.startsWith('#c=')) location.reload();
});
