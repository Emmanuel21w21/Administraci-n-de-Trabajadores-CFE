// ================= UTILIDADES =================
function showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    const colors = type === 'success' ? 'bg-emerald-700 text-white' : 'bg-rose-600 text-white';
    const icon = type === 'success' ? 'fa-circle-check' : 'fa-circle-exclamation';
    toast.className = `${colors} px-4 py-3 rounded-xl shadow-xl flex items-center space-x-3 text-sm font-semibold pointer-events-auto transition-all duration-300 transform translate-y-2 opacity-0`;
    toast.innerHTML = `<i class="fa-solid ${icon}"></i><span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => toast.classList.remove('translate-y-2', 'opacity-0'), 10);
    setTimeout(() => {
        toast.classList.add('opacity-0', 'translate-y-2');
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

function saveData() {
    localStorage.setItem('credencial_workers', JSON.stringify(workers));
    localStorage.setItem('credencial_notifications', JSON.stringify(notificationsLog));
    updateMetrics();

    if (!firebaseReady || !cloudUser || !cloudReady) {
        if (firebaseReady && cloudUser && !cloudReady) {
            console.warn('Los cambios esperan a que termine la sincronización inicial.');
        }
        return;
    }

    const dataToSave = {
        workers: JSON.parse(JSON.stringify(workers)),
        notificationsLog: JSON.parse(JSON.stringify(notificationsLog)),
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    };
    cloudSaveQueue = cloudSaveQueue
        .then(() => cloudDocument.set(dataToSave))
        .catch((error) => {
            console.error('Error guardando en Firebase:', error);
            showToast('No se pudo guardar en la nube. Revisa tu conexión.', 'error');
        });
}

function switchTab(tab) {
    ['trabajadores', 'credenciales', 'escaner', 'notificaciones', 'reportes'].forEach(t => {
        document.getElementById(`view-${t}`).classList.add('hidden');
        document.getElementById(`nav-${t}`).classList.remove('bg-emerald-700', 'text-white', 'shadow-lg', 'shadow-emerald-900/40');
        document.getElementById(`nav-${t}`).classList.add('text-emerald-100', 'hover:bg-emerald-900');
    });

    document.getElementById(`view-${tab}`).classList.remove('hidden');
    document.getElementById(`nav-${tab}`).classList.add('bg-emerald-700', 'text-white', 'shadow-lg', 'shadow-emerald-900/40');
    document.getElementById(`nav-${tab}`).classList.remove('text-emerald-100', 'hover:bg-emerald-900');

    const headers = {
        trabajadores: "Administración de Trabajadores CFE",
        credenciales: "Generador de Credenciales Digitales CFE",
        escaner: "Escáner / Consulta Pública QR CFE",
        notificaciones: "Notificaciones Automáticas por Correo",
        reportes: "Reportes y Estadísticas Institucionales CFE"
    };
    document.getElementById('header-title').innerText = headers[tab];

    if (tab === 'credenciales') populateCredentialSelect();
    if (tab === 'escaner') populateQRSelect();
    if (tab === 'notificaciones') renderNotificationsTable();
    if (tab === 'reportes') renderReport();
}

function updateMetrics() {
    document.getElementById('stat-total').innerText = workers.length;
    if (document.getElementById('stat-total-card')) document.getElementById('stat-total-card').innerText = workers.length;
    if (document.getElementById('stat-vigentes-card')) document.getElementById('stat-vigentes-card').innerText = workers.filter(w => getComputedStatus(w) === 'Vigente').length;
    if (document.getElementById('stat-inactivos-card')) document.getElementById('stat-inactivos-card').innerText = workers.filter(w => getComputedStatus(w) === 'Inactiva').length;
    if (document.getElementById('stat-vencidos-card')) document.getElementById('stat-vencidos-card').innerText = workers.filter(w => getComputedStatus(w) === 'Vencida').length;
}

function getComputedStatus(worker) {
    if (worker.estado === 'Inactiva') return 'Inactiva';
    const today = new Date().toISOString().split('T')[0];
    if (worker.vigencia < today) return 'Vencida';
    return 'Vigente';
}

function filterWorkersByQuery(q) {
    q = (q || '').trim().toLowerCase();
    if (!q) return workers;
    return workers.filter(w =>
        w.nombre.toLowerCase().includes(q) ||
        String(w.numTrabajador).toLowerCase().includes(q)
    );
}
