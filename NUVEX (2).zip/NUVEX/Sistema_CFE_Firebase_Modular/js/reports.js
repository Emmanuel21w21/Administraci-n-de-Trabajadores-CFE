// ================= REPORTES =================
function renderReport() {
    const areaSelect = document.getElementById('report-filter-area');
    const currentAreaVal = areaSelect.value;
    const areas = [...new Set(workers.map(w => w.area))];
    areaSelect.innerHTML = `<option value="todas">Todas las áreas</option>`;
    areas.forEach(a => { areaSelect.innerHTML += `<option value="${a}">${a}</option>`; });
    areaSelect.value = areas.includes(currentAreaVal) ? currentAreaVal : "todas";

    const areaFilter = areaSelect.value;
    const statusFilter = document.getElementById('report-filter-status').value;
    const tbody = document.getElementById('report-tbody');
    tbody.innerHTML = '';

    const filtered = workers.filter(w => {
        const status = getComputedStatus(w);
        const matchesArea = areaFilter === 'todas' || w.area === areaFilter;
        const matchesStatus = statusFilter === 'todos' || status === statusFilter;
        return matchesArea && matchesStatus;
    });

    updateMetrics();

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="p-6 text-center text-slate-400">No se encontraron trabajadores para este reporte.</td></tr>`;
        return;
    }

    filtered.forEach(w => {
        const status = getComputedStatus(w);
        let color = 'text-emerald-700';
        if (status === 'Inactiva') color = 'text-amber-600';
        if (status === 'Vencida') color = 'text-rose-600';

        tbody.innerHTML += `
            <tr class="hover:bg-emerald-50/50 border-b border-emerald-50">
                <td class="p-3 font-bold text-emerald-950">${w.nombre}</td>
                <td class="p-3 font-mono text-emerald-700 font-semibold text-xs">${w.numTarjeta}</td>
                <td class="p-3 text-slate-600">${w.area}</td>
                <td class="p-3 text-slate-600">${w.cargo}</td>
                <td class="p-3 text-slate-600">${w.vigencia}</td>
                <td class="p-3 font-bold ${color}">${status}</td>
            </tr>
        `;
    });
}
