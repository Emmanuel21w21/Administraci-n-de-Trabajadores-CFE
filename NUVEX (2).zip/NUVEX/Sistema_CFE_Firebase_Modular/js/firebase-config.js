// ================= CONFIGURACIÓN DE FIREBASE =================
const FORMSPREE_URL = "https://formspree.io/f/xkjjyzqb";
const PUBLIC_BASE_URL = "";

const firebaseConfig = {
    apiKey: "AIzaSyChUrhRLpAamx8H-AIqCTHpHI2gZc0g0xE",
    authDomain: "sistema-cfe-cc199.firebaseapp.com",
    projectId: "sistema-cfe-cc199",
    storageBucket: "sistema-cfe-cc199.firebasestorage.app",
    messagingSenderId: "749328103819",
    appId: "1:749328103819:web:e3e32997ae84aa08a2d78e",
    measurementId: "G-G2TZB9R3VT"
};

const ADMIN_USER = "admin";
const ADMIN_FIREBASE_EMAIL = "admin@cfe-system.app";
let firebaseReady = false;
let cloudReady = false;
let cloudUser = null;
let cloudUnsubscribe = null;
let cloudSaveQueue = Promise.resolve();
let firstCloudSnapshot = true;
let cloudDocument = null;

let workers = JSON.parse(localStorage.getItem('credencial_workers')) || [];
let notificationsLog = JSON.parse(localStorage.getItem('credencial_notifications')) || [];
let currentQrUrl = "";

try {
    const configIsComplete = firebaseConfig.apiKey !== "PEGA_AQUI_TU_API_KEY" &&
        firebaseConfig.projectId !== "PEGA_AQUI_TU_PROJECT_ID" &&
        firebaseConfig.appId !== "PEGA_AQUI_TU_APP_ID";
    if (configIsComplete) {
        if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
        firebase.auth().setPersistence(firebase.auth.Auth.Persistence.LOCAL);
        cloudDocument = firebase.firestore().collection("cfe_system").doc("main_data");
        firebaseReady = true;
    }
} catch (error) {
    console.error("No se pudo inicializar Firebase:", error);
}
