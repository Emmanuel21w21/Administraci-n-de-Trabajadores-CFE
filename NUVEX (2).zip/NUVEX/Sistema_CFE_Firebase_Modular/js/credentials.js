// ================= CREDENCIALES Y GENERACIÓN DE PDF / QR =================
function getBaseUrl() {
    return (PUBLIC_BASE_URL || location.href.split('#')[0]);
}

function encodePayload(obj) {
    const bytes = pako.deflate(new TextEncoder().encode(JSON.stringify(obj)));
    let bin = '';
    bytes.forEach(b => bin += String.fromCharCode(b));
    return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function decodePayload(str) {
    str = str.replace(/-/g, '+').replace(/_/g, '/');
    while (str.length % 4) str += '=';
    const bin = atob(str);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return JSON.parse(new TextDecoder().decode(pako.inflate(bytes)));
}

function makeThumb(src, w = 40, h = 53, q = 0.45) {
    return new Promise(resolve => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
            const c = document.createElement('canvas');
            c.width = w; c.height = h;
            const ctx = c.getContext('2d');
            const r = Math.max(w / img.width, h / img.height);
            const dw = img.width * r, dh = img.height * r;
            ctx.drawImage(img, (w - dw) / 2, (h - dh) / 2, dw, dh);
            try { resolve(c.toDataURL('image/jpeg', q).split(',')[1]); }
            catch (e) { resolve(null); }
        };
        img.onerror = () => resolve(null);
        img.src = src;
    });
}

async function buildCredentialUrl(w) {
    const p = {
        n: w.nombre,
        t: w.numTrabajador,
        a: w.area,
        c: w.cargo,
        k: w.numTarjeta,
        i: w.inicio || '',
        v: w.vigencia,
        e: w.estado
    };
    if (/^https?:\/\//i.test(w.foto) && w.foto.length <= 200) {
        p.f = w.foto;
    } else {
        const thumb = await makeThumb(w.foto);
        if (thumb) p.j = thumb;
    }
    return getBaseUrl() + '#c=' + encodePayload(p);
}

function drawQR(containerId, text, size) {
    const el = document.getElementById(containerId);
    el.innerHTML = '';
    new QRCode(el, {
        text: text,
        width: size,
        height: size,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.L
    });
}

function downloadQR() {
    const canvas = document.querySelector('#qr-big-container canvas');
    if (!canvas) return showToast('Primero selecciona un trabajador.', 'error');
    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = 'QR_credencial.png';
    a.click();
}

function openQRLink() {
    if (currentQrUrl) window.open(currentQrUrl, '_blank');
}

function getStatusFromPayload(p) {
    if (p.e === 'Inactiva') return 'Inactiva';
    const today = new Date().toISOString().split('T')[0];
    return p.v < today ? 'Vencida' : 'Vigente';
}

function payloadPhotoSrc(p) {
    if (p.f) return p.f;
    if (p.j) return 'data:image/jpeg;base64,' + p.j;
    return null;
}

function loadImageDataUrl(src) {
    return new Promise(resolve => {
        if (!src) return resolve(null);
        if (src.startsWith('data:')) return resolve(src);
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
            const c = document.createElement('canvas');
            c.width = img.width; c.height = img.height;
            c.getContext('2d').drawImage(img, 0, 0);
            try { resolve(c.toDataURL('image/jpeg', 0.92)); } catch (e) { resolve(null); }
        };
        img.onerror = () => resolve(null);
        img.src = src;
    });
}

async function buildCredentialPDF(p) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: 'mm', format: 'a4' });
    const status = getStatusFromPayload(p);
    const colors = { Vigente: [16, 185, 129], Inactiva: [245, 158, 11], Vencida: [225, 29, 72] };

    doc.setFillColor(2, 44, 34);
    doc.rect(0, 0, 210, 38, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.text('COMISIÓN FEDERAL DE ELECTRICIDAD', 105, 17, { align: 'center' });
    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');
    doc.text('Credencial Oficial de Identificación', 105, 27, { align: 'center' });

    doc.setDrawColor(6, 78, 59);
    doc.setLineWidth(0.8);
    doc.roundedRect(20, 50, 170, 130, 4, 4);

    const photo = await loadImageDataUrl(payloadPhotoSrc(p));
    if (photo) {
        doc.addImage(photo, 'JPEG', 28, 60, 45, 60);
    } else {
        doc.setFillColor(230, 240, 236);
        doc.rect(28, 60, 45, 60, 'F');
        doc.setTextColor(120, 120, 120);
        doc.setFontSize(9);
        doc.text('Sin fotografía', 50.5, 91, { align: 'center' });
    }

    const col = colors[status];
    doc.setFillColor(col[0], col[1], col[2]);
    doc.roundedRect(28, 124, 45, 9, 2, 2, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text(status.toUpperCase(), 50.5, 130.2, { align: 'center' });

    const campos = [
        ['NOMBRE COMPLETO', p.n],
        ['NÚMERO DE TRABAJADOR', p.t],
        ['ÁREA DE ADSCRIPCIÓN', p.a],
        ['CARGO', p.c],
        ['NÚMERO DE TARJETA', p.k],
        ['VIGENCIA', `Del ${p.i || 'N/A'} al ${p.v}`],
        ['ESTADO DE LA CREDENCIAL', status]
    ];
    let y = 64;
    campos.forEach(([label, val]) => {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8);
        doc.setTextColor(5, 120, 90);
        doc.text(label, 82, y);
        doc.setFontSize(12);
        doc.setTextColor(2, 44, 34);
        const lines = doc.splitTextToSize(String(val || '--'), 100);
        doc.text(lines, 82, y + 5.5);
        y += 12 + (lines.length - 1) * 5;
    });

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(110, 110, 110);
    doc.text('Documento generado al escanear el código QR oficial. Estado verificado al: ' +
        new Date().toLocaleString('es-MX'), 105, 192, { align: 'center' });
    doc.text('Por seguridad, la CURP y los datos de contacto no se incluyen en este documento.',
        105, 197, { align: 'center' });

    return doc;
}

function safeFileName(p) {
    return 'Credencial_' + String(p.k).replace(/[^\w-]/g, '') + '.pdf';
}

async function downloadAdminPDF() {
    if (!currentQrUrl) return showToast('Selecciona un trabajador.', 'error');
    const p = decodePayload(currentQrUrl.split('#c=')[1]);
    const doc = await buildCredentialPDF(p);
    doc.save(safeFileName(p));
}

function populateCredentialSelect() {
    const select = document.getElementById('select-credential-worker');
    const q = document.getElementById('search-credential-worker').value;
    const prev = select.value;
    const list = filterWorkersByQuery(q);
    select.innerHTML = '';

    if (workers.length === 0) {
        select.innerHTML = `<option value="">No hay trabajadores registrados</option>`;
    } else if (list.length === 0) {
        select.innerHTML = `<option value="">Sin coincidencias</option>`;
    } else {
        list.forEach(w => {
            select.innerHTML += `<option value="${w.id}">${w.nombre} (No. ${w.numTrabajador} · ${w.area} - Card: ${w.numTarjeta})</option>`;
        });
        if (list.some(w => String(w.id) === prev)) select.value = prev;
    }
    renderDigitalCard();
}

async function renderDigitalCard() {
    const id = document.getElementById('select-credential-worker').value;
    const w = workers.find(x => x.id == id);

    if (!w) {
        document.getElementById('card-front-name').innerText = "--";
        document.getElementById('card-front-num').innerText = "--";
        document.getElementById('card-front-areacargo').innerText = "--";
        document.getElementById('card-back-cardnum').innerText = "--";
        document.getElementById('card-back-vigencia').innerText = "--";
        document.getElementById('card-qr-container').innerHTML = "";
        document.getElementById('qr-big-container').innerHTML = "";
        document.getElementById('qr-url-info').innerText = "--";
        currentQrUrl = "";
        return;
    }

    const status = getComputedStatus(w);

    document.getElementById('card-front-photo').src = w.foto;
    document.getElementById('card-front-name').innerText = w.nombre;
    document.getElementById('card-front-num').innerText = w.numTrabajador;
    document.getElementById('card-front-areacargo').innerText = `${w.area} / ${w.cargo}`;

    const badge = document.getElementById('card-front-badge');
    badge.innerText = status.toUpperCase();
    const base = "absolute -bottom-2 left-1/2 -translate-x-1/2 text-[9px] font-bold px-2.5 py-0.5 rounded-full uppercase shadow text-white ";
    badge.className = base + (status === 'Vigente' ? 'bg-emerald-500' : status === 'Inactiva' ? 'bg-amber-500' : 'bg-rose-500');

    document.getElementById('card-back-cardnum').innerText = w.numTarjeta;
    document.getElementById('card-back-vigencia').innerText = w.vigencia;

    if (location.protocol === 'file:' && !PUBLIC_BASE_URL) {
        showToast('Aloja el HTML en internet y pon su URL en PUBLIC_BASE_URL para que el QR abra en celulares.', 'error');
    }

    currentQrUrl = await buildCredentialUrl(w);
    drawQR('card-qr-container', currentQrUrl, 130);
    drawQR('qr-big-container', currentQrUrl, 280);
    document.getElementById('qr-url-info').innerText = currentQrUrl.length + ' caracteres';
}
