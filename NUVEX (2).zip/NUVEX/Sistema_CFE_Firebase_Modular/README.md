# Sistema de Credencialización Web (CFE)

Este proyecto ha sido estructurado y dividido modularmente en archivos independientes HTML, CSS y JS para facilitar su mantenimiento y escalabilidad.

## Estructura del Proyecto

```
sistema-cfe/
│
├── index.html               # Estructura HTML principal
├── css/
│   └── styles.css           # Estilos personalizados (media print, etc.)
└── js/
    ├── firebase-config.js   # Configuración de Firebase y Formspree
    ├── auth.js              # Autenticación y Sincronización en la Nube
    ├── utils.js             # Funciones auxiliares (Toasts, Tabs, Filtros generales)
    ├── workers.js           # Gestión e interfaz de Trabajadores (CRUD)
    ├── credentials.js       # Generación de Credenciales, Códigos QR y PDF
    ├── scanner.js           # Consulta Pública y Simulador de Escáner QR
    ├── notifications.js     # Envío e Historial de Notificaciones por Correo
    ├── reports.js           # Generación y Filtrado de Reportes
    └── app.js               # Eventos de inicio de aplicación
```

## Instrucciones de Despliegue
1. Descomprime el archivo ZIP.
2. Abre el archivo `index.html` en un servidor web local o súbelo a un hosting (GitHub Pages, Netlify, Vercel, Firebase Hosting, etc.).
3. Configura el parámetro `PUBLIC_BASE_URL` en `js/firebase-config.js` con el dominio público donde esté alojada la aplicación para que los códigos QR escaneados abran la credencial en dispositivos móviles.
